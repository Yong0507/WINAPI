#define Window_Size_X 1000
#define Window_Size_Y 1000

#define P_IMAGE_SIZE  32
#define P_DIR_LEFT    32
#define P_DIR_RIGHT   0 

#define M_IMAGE_SIZE  44

#define BULLET_AMOUNT 20
#define MONSTER_AMOUNT 66
